/**
 * Internal implementation classes for efficient handling of
 * of symbols in JSON (field names in Objects)
 */
package org.codehaus.jackson.sym;
